﻿from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from content.models import CompanyInfo, Statistic, Service
from properties.models import Property


def home(request):
    """Homepage with dynamic content from database - Stunning Design"""
    company = CompanyInfo.objects.first()
    stats = Statistic.objects.all()[:4]  # Get 4 stats for the new design
    services = Service.objects.all()[:3]
    featured_properties = Property.objects.filter(status='available').prefetch_related('photos')[:6]  # Show more properties
    
    context = {
        'company': company,
        'stats': stats,
        'services': services,
        'featured_properties': featured_properties,
    }
    
    return render(request, 'home-premium.html', context)


@login_required
def dashboard(request):
    return render(request, 'users/dashboard.html')


def about(request):
    return render(request, 'about.html')


def contact(request):
    return render(request, 'contact.html')


def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f"Welcome back, {user.get_full_name() or user.username}!")
            return redirect('dashboard')
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    
    return render(request, 'users/login.html', {'form': form})


def user_register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, "Account created successfully! Please login.")
            return redirect('login')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = UserCreationForm()
    
    return render(request, 'users/register.html', {'form': form})


def user_logout(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect('home')
