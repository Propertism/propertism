# SCCB: PROPERTISM-CSS-RATIONALIZATION-001

**Status**: PARKED  
**Scope**: realtor-web CSS structure cleanup  
**Owner**: Kiro  
**Objective**: Reduce fragmented CSS structure and archive redundant styling layers while keeping runtime behavior intact.

---

## BASE PATH
```
realtor-web/static/css/
```

## CURRENT FILES (9 files)
```
chat-widget.css
enhanced-features.css
mobile-layout.css
premium-styles.css
propertism-styles.css
realtor-overrides.css
stunning-design.css
styles.css
utilities.css
```

---

## TARGET STRUCTURE (6 ACTIVE FILES)
```
static/css/
├── base.css           (core styles)
├── components.css     (reusable components)
├── pages.css          (page-specific styles)
├── mobile.css         (responsive/mobile)
├── utilities.css      (utility classes - NO CHANGE)
└── chat-widget.css    (chat widget - NO CHANGE)
```

---

## FILES TO RETAIN (NO CHANGE)
- `static/css/utilities.css`
- `static/css/chat-widget.css`

---

## FILES TO BE CONSOLIDATED

### MERGE INTO base.css
- `static/css/styles.css`
- `static/css/propertism-styles.css`

### MERGE INTO components.css
- `static/css/premium-styles.css`
- `static/css/stunning-design.css`
- `static/css/enhanced-features.css`

### MERGE INTO pages.css
- `static/css/realtor-overrides.css`

### MERGE INTO mobile.css
- `static/css/mobile-layout.css`

---

## ARCHIVE STRUCTURE

Create directory:
```
static/css/_archive/
```

Move the following files AFTER merge verification:
```
static/css/_archive/styles.css
static/css/_archive/propertism-styles.css
static/css/_archive/premium-styles.css
static/css/_archive/stunning-design.css
static/css/_archive/enhanced-features.css
static/css/_archive/realtor-overrides.css
static/css/_archive/mobile-layout.css
```

---

## FILES NOT IN SCOPE (DO NOT MODIFY)
```
staticfiles/admin/css/*
staticfiles/rest_framework/css/*
staticfiles/modeltranslation/css/*
static/dist/assets/properties.css
```
These belong to Django Admin / DRF / Vendor assets.

---

## IMPLEMENTATION STEPS

1. **Create new consolidated files**
   - base.css
   - components.css
   - pages.css
   - mobile.css

2. **Move rules from source files into the appropriate consolidated files**

3. **Update template CSS imports to:**
   ```html
   <link rel="stylesheet" href="{% static 'css/base.css' %}">
   <link rel="stylesheet" href="{% static 'css/components.css' %}">
   <link rel="stylesheet" href="{% static 'css/pages.css' %}">
   <link rel="stylesheet" href="{% static 'css/mobile.css' %}">
   <link rel="stylesheet" href="{% static 'css/utilities.css' %}">
   <link rel="stylesheet" href="{% static 'css/chat-widget.css' %}">
   ```

4. **Verify layout integrity across:**
   - homepage
   - property listing
   - property detail
   - contact page
   - mobile viewport (320px, 375px, 414px, 768px, 1024px, 1920px)

5. **After verification, move original files to `/static/css/_archive/`**

---

## ACCEPTANCE CRITERIA

- ✅ Site renders identically to current production UI
- ✅ CSS file count reduced from 9 → 6
- ✅ No broken layout on desktop or mobile
- ✅ Django admin and DRF UI remain untouched
- ✅ Archived files preserved for rollback
- ✅ Load order maintained (base → components → pages → mobile → utilities → chat)

---

## ROLLBACK

Restore archived files from:
```
static/css/_archive/
```

Revert template CSS includes to original imports.

---

## PREREQUISITES (MUST COMPLETE FIRST)

- [ ] Current mobile layout fixes verified
- [ ] 2x2 trust strip confirmed working on mobile
- [ ] Hamburger menu tested and working
- [ ] Desktop view verified (no regressions)
- [ ] Changes committed to git
- [ ] Changes deployed to production
- [ ] User sign-off on current state

---

## NOTES

**Why Parked:**
- Active mobile layout testing in progress
- Recent CSS changes not yet verified
- Need stable baseline before consolidation
- Risk of breaking working fixes

**When to Resume:**
- After all current fixes are verified
- After production deployment
- After user confirms everything works
- When we have a stable rollback point

---

**Created**: March 8, 2026  
**Last Updated**: March 8, 2026  
**Next Review**: After mobile fixes verified and deployed
