"""Custom middleware for handling health checks and other special cases."""

from django.http import HttpResponse


class HealthCheckMiddleware:
    """
    Middleware to handle health check requests before ALLOWED_HOSTS validation.
    
    This ensures load balancer health checks always succeed regardless of
    the Host header sent by the load balancer.
    """
    
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        # Handle health check before any other middleware
        if request.path == '/health/':
            return HttpResponse("OK", content_type="text/plain", status=200)
        
        response = self.get_response(request)
        return response
