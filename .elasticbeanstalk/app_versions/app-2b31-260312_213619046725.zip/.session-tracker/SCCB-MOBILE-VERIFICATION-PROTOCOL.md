# SCCB: PROPERTISM-MOBILE-VERIFICATION-PROTOCOL-003

**Status**: ACTIVE - AWAITING USER VERIFICATION  
**Scope**: Structured verification of frozen mobile CSS state  
**Owner**: Kiro  
**Objective**: Replace subjective validation with measurable layout checks.

---

## VERIFICATION ENVIRONMENT

- **Viewport**: 375 × 667 (iPhone SE)
- **Zoom**: 100%
- **Browser**: Chrome DevTools mobile emulator

---

## STEP 1 — VIEWPORT WIDTH CHECK

**Inspect element**: `<body>` or `<html>`

**Expected computed values**:
```
width = 375px
overflow-x = hidden or visible (not scroll)
```

**Confirm**:
- [ ] No horizontal scrollbar
- [ ] No grey margin outside page container

**Report**: `VIEWPORT WIDTH → OK / ISSUE`

---

## STEP 2 — HEADER VERIFICATION

**Inspect**: `.site-header` or `.header`

**Confirm**:
- Header height ≤ 70px

**Logo**:
- height ≈ 32px

**Action icons**:
- height ≈ 36–40px

**Confirm**:
- [ ] Icons aligned horizontally
- [ ] No icon overlap
- [ ] No clipping

**Report**: `HEADER → OK / ISSUE`

---

## STEP 3 — HERO SECTION

**Inspect**: `.hero` or `.hero-section`

**Confirm**:
- Hero container width = 100%

**Check**:
```
background-image present
min-height ≥ 320px
```

**Text**:
- [ ] Title fully visible
- [ ] Text not overflowing container

**Report**: `HERO → OK / ISSUE`

---

## STEP 4 — TRUST STRIP GRID

**Inspect trust strip container**:
- `.trust-strip`
- `.features-grid`
- `.nri-features`

**Expected computed layout**:
```
display = grid
grid-template-columns = 1fr 1fr
```

**Confirm**:
- [ ] Exactly 2 columns
- [ ] Exactly 2 rows
- [ ] Items aligned
- [ ] No overflow

**Report**: `TRUST STRIP → OK / ISSUE`

---

## STEP 5 — LAYOUT WIDTH

**Scroll page vertically.**

**Confirm**:
- [ ] No element extends beyond viewport
- [ ] No horizontal scroll appears
- [ ] Floating chat button inside viewport

**Report**: `LAYOUT WIDTH → OK / ISSUE`

---

## RESPONSE FORMAT

Return only:

```
VIEWPORT WIDTH → OK / ISSUE
HEADER → OK / ISSUE
HERO → OK / ISSUE
TRUST STRIP → OK / ISSUE
LAYOUT WIDTH → OK / ISSUE
```

**If ISSUE is reported, include**:
- selector name
- CSS rule causing problem
- source CSS file
- proposed minimal fix

---

## RULE

**No CSS modification is allowed until the verification report is completed.**

---

**Created**: March 8, 2026  
**Status**: AWAITING USER VERIFICATION  
**Next Action**: User must complete verification checklist
