# SCCB: PROPERTISM-AGENT-CHANGE-DISCIPLINE-001

**Status**: ACTIVE  
**Scope**: Enforce controlled change discipline for live production site fixes  
**Owner**: Kiro  
**Objective**: Stop ad-hoc trial-and-error modifications and enforce structured debugging and controlled CSS changes.

---

## PROBLEM OBSERVED

During mobile responsive fixes the agent is applying changes using a casual approach:

**Examples observed:**
- "Let me revert and try this"
- "My CSS was too aggressive"
- Multiple unstructured iterations

**This behavior is not acceptable for a live production site.**

The current approach causes:
- ❌ Regression risk (hero section disappearing)
- ❌ Unpredictable layout changes
- ❌ Inefficient debugging cycles
- ❌ Difficulty tracking root cause

---

## MANDATORY CHANGE APPROACH (EFFECTIVE IMMEDIATELY)

Before applying ANY CSS change, Kiro must follow this sequence:

### 1. IDENTIFY ROOT CAUSE
Use DevTools → Inspect Element → Computed Styles.

### 2. IDENTIFY SOURCE FILE
Determine exact CSS file and line number responsible.

### 3. CONFIRM TARGET COMPONENT
Specify which component is being modified:
- header
- hero
- trust-strip
- grid container

### 4. PROPOSE FIX
Explain:
- which selector will be changed
- which rule will be added or overridden
- expected visual outcome

### 5. APPLY SINGLE CHANGE
Only one change per iteration.

### 6. VERIFY IMPACT
Validate:
- mobile layout
- hero visibility
- header alignment
- trust-strip layout

---

## STRICT RULES

### The agent MUST NOT:
- ❌ Randomly modify multiple CSS rules
- ❌ Revert and retry blindly
- ❌ Change unrelated sections (hero while fixing header)
- ❌ Apply global CSS overrides without inspection

### The agent MUST:
- ✅ Isolate the exact CSS selector
- ✅ Apply minimal targeted change
- ✅ Confirm before modifying additional sections

---

## ACCEPTANCE CRITERIA

Future fixes must demonstrate:
- ✅ Root cause identified before modification
- ✅ Minimal CSS edits
- ✅ No unrelated layout regressions
- ✅ Structured debugging steps documented

---

## RATIONALE

Propertism site is already live.

All fixes must follow controlled engineering discipline, not exploratory trial-and-error editing.

---

## INCIDENT LOG

### Incident 1: Hero Section Disappearance
**Date**: March 8, 2026  
**Issue**: Agent modified hero section CSS while attempting to fix header size  
**Impact**: Hero section completely disappeared from mobile view  
**Root Cause**: Applied aggressive CSS overrides without isolating target component  
**Resolution**: Reverted hero changes, kept only header modifications  
**Lesson**: Must isolate component changes, never modify multiple sections simultaneously

---

**Created**: March 8, 2026  
**Last Updated**: March 8, 2026  
**Status**: ENFORCED
