# SCCB: PROPERTISM-DEEP-INVESTIGATION-PROTOCOL-010

**Scope:** Enforce comprehensive root cause analysis before applying CSS fixes  
**Owner:** Kiro  
**Objective:** Eliminate trial-and-error iterations by investigating ALL sources of truth first

---

## THE PROBLEM

When a CSS issue persists after multiple fix attempts, the root cause is usually:
- **Conflicting rules in multiple files** (external CSS + inline styles)
- **CSS cascade/specificity issues** (later-loading styles override earlier ones)
- **Template inline styles** overriding external stylesheets
- **Media query conflicts** in different files targeting same selectors

**Previous Mistake:** Applied fixes to `mobile-layout.css` while template's inline `@media` rules were directly conflicting. Should have identified and removed the template rules first.

---

## MANDATORY INVESTIGATION SEQUENCE

### STEP 1: IDENTIFY ALL SOURCE FILES
Before making ANY CSS change, list all files that could affect the component:

```
For hero section:
- realtor-web/static/css/premium-styles.css
- realtor-web/static/css/propertism-styles.css
- realtor-web/static/css/mobile-layout.css
- realtor-web/uilayers/templates/home-premium.html (inline <style>)
- realtor-web/uilayers/templates/base.html (CSS load order)
```

### STEP 2: SEARCH FOR ALL CONFLICTING RULES
Use grepSearch to find EVERY rule affecting the selector:

```
Query: \.hero-hybrid-has-image
Query: \.hero-hybrid-content
Query: \.hero-eyebrow
Query: @media.*768px
Query: @media.*480px
```

**Document findings:**
- File name
- Line number
- Rule content
- Specificity level

### STEP 3: DETERMINE CSS LOAD ORDER
Check `base.html` to understand which files load when:

```
1. premium-styles.css (loads first)
2. propertism-styles.css
3. mobile-layout.css (loads last - highest priority)
4. Template inline <style> (loads AFTER all external CSS)
```

**Critical:** Template inline styles override external CSS files because they load last.

### STEP 4: IDENTIFY CONFLICTS
Compare rules across all files:

```
File A: .hero-hybrid-content { position: relative; }
File B: .hero-hybrid-content { position: absolute; bottom: 0; }
Template: .hero-hybrid-content { position: absolute; bottom: 140px; }

CONFLICT: Three different position values
WINNER: Template (loads last)
```

### STEP 5: REMOVE CONFLICTS AT SOURCE
**DO NOT** try to override conflicting rules with `!important`

**DO** remove the conflicting rule from its source file:

```
❌ WRONG: Add !important to mobile-layout.css to override template
✅ RIGHT: Remove conflicting @media block from template entirely
```

### STEP 6: CONSOLIDATE IN ONE LOCATION
After removing conflicts, consolidate all mobile rules in ONE file:

```
Recommended: mobile-layout.css (external CSS, loads before template)
Reason: Easier to maintain, no inline style conflicts
```

### STEP 7: VERIFY NO REMAINING CONFLICTS
Search again for the selector in all files:

```
grepSearch: \.hero-hybrid-content
Expected: Only appears in mobile-layout.css (and base template HTML)
```

---

## CHECKLIST BEFORE APPLYING FIX

- [ ] Read ENTIRE template file (not just visible section)
- [ ] Search for selector in ALL CSS files
- [ ] Search for selector in ALL template files
- [ ] Document all conflicting rules with line numbers
- [ ] Identify which file loads last (has priority)
- [ ] Remove conflicts at source (don't override)
- [ ] Consolidate rules in one location
- [ ] Verify no remaining conflicts
- [ ] Apply single comprehensive fix
- [ ] Collect static files
- [ ] Test and verify

---

## EXAMPLE: HERO SECTION FIX (CORRECT APPROACH)

### Investigation Phase:
1. Search for `.hero-hybrid-content` in all files
2. Found in:
   - `mobile-layout.css` line 414
   - `home-premium.html` line 95 (inline style, loads LAST)
3. Template rule: `position: absolute; bottom: 140px;`
4. Mobile-layout rule: `position: absolute; bottom: 200px;`
5. **Conflict:** Template wins because it loads last

### Fix Phase:
1. Remove entire `@media (max-width: 768px)` block from template
2. Remove entire `@media (max-width: 480px)` block from template
3. Consolidate all mobile rules in `mobile-layout.css`
4. Set `bottom: 180px` (final value)
5. Collect static files
6. Test

---

## RULES FOR FUTURE SESSIONS

**BEFORE MAKING ANY CSS CHANGE:**
1. Read the complete source file (not partial sections)
2. Search for ALL occurrences of the selector
3. Identify conflicts across files
4. Remove conflicts at source
5. Consolidate in one location
6. Apply single comprehensive fix

**NEVER:**
- Make multiple incremental changes hoping one works
- Override conflicting rules with `!important`
- Ignore inline styles in templates
- Skip reading complete files

**ALWAYS:**
- Do deep investigation first
- Remove conflicts at source
- Consolidate rules in one place
- Apply comprehensive fix
- Verify no remaining conflicts

---

## REFERENCE: CSS CASCADE & SPECIFICITY

**Load Order (Highest Priority Last):**
1. Browser defaults
2. External stylesheets (in order)
3. Template inline `<style>` blocks
4. Inline `style=""` attributes

**For Propertism:**
- `premium-styles.css` loads first
- `propertism-styles.css` loads second
- `mobile-layout.css` loads third
- Template `<style>` loads LAST (highest priority)

**Specificity (Highest Priority Last):**
1. Element selectors (low)
2. Class selectors (medium)
3. ID selectors (high)
4. `!important` (highest)

**Solution:** Remove conflicts at source instead of using `!important`

---

## WHEN TO USE THIS PROTOCOL

- Any CSS issue that requires multiple fix attempts
- When changes don't take effect as expected
- When different files have conflicting rules
- When template inline styles override external CSS
- Before making changes to production sites

---

**Status:** Active Protocol  
**Last Updated:** Current Session  
**Next Review:** After each major CSS fix
